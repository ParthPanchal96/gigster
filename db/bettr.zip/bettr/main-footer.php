<script src="<?php echo $serverpath;?>js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/jquery.pageslide.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="<?php echo $serverpath;?>js/plugins/morris/morris.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>

<script src="<?php echo $serverpath;?>js/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/AdminLTE/app.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/AdminLTE/dashboard.js" type="text/javascript"></script>
<script src="<?php echo $serverpath;?>js/AdminLTE/demo.js" type="text/javascript"></script>
 <script src="<?php echo $serverpath;?>js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="<?php echo $serverpath;?>js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    
<iframe name="submitframe" id="submitframe" class="mhidden"></iframe>
