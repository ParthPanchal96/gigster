<nav class="navbar navbar-static-top" role="navigation" style="z-index:65020;"> 
  <!-- Sidebar toggle button--> 
  <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
  <div class="navbar-right">
   
  </div>
</nav>