<?php
define('CONSUMER_KEY', '3szX12OjvGsBSL2eTF4VtPcso');
define('CONSUMER_SECRET', 'WPf35X3VcMqTwlV1bZtDiIj6GJD0JdKvuBXyqfvmrOiS3wjLgI');
?>
