<section class="content-header">
  <h1><i class="fa fa-comments"></i> Inbox</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo $serverpath;?>dashboard"><i class="fa fa-dashboard"></i> My Account</a></li>
    <li class="active">Inbox</li>
  </ol>
</section>

        <!-- AdminLTE App -->

<div  id="myGigs" class="box-body table-responsive no-padding"></div>
<script type="text/javascript">
display_all_messages('<?php echo $serverpath;?>');
</script> 
